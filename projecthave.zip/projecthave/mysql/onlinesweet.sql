-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 31, 2022 at 07:46 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinesweet`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartId` int(11) NOT NULL,
  `oid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `priceUnit` int(11) NOT NULL,
  `totalBill` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cartId`, `oid`, `pid`, `uid`, `name`, `quantity`, `priceUnit`, `totalBill`) VALUES
(1, 3, 2, 2, 'Product 2', 1, 450, 450),
(2, 4, 2, 2, 'Product 2', 1, 450, 450),
(3, 4, 2, 2, 'Product 2', 2, 450, 900),
(4, 5, 2, 2, 'Product 2', 1, 450, 450),
(5, 6, 2, 2, 'Product 2', 1, 450, 450),
(6, 7, 2, 2, 'Product 2', 4, 450, 1800),
(7, 7, 2, 2, 'Product 2', 2, 450, 900),
(8, 8, 2, 2, 'Product 2', 1, 450, 450),
(9, 8, 2, 2, 'Product 2', 2, 450, 900),
(10, 9, 1, 2, 'Product 1', 2, 500, 1000),
(11, 9, 2, 2, 'Product 2', 2, 450, 900),
(12, 10, 1, 2, 'Product 1', 3, 500, 1500),
(13, 10, 2, 2, 'Product 2', 2, 450, 900),
(14, 11, 1, 2, 'Product 1', 5, 500, 2500),
(15, 11, 2, 2, 'Product 2', 2, 450, 900),
(16, 12, 1, 2, 'Product 1', 3, 500, 1500),
(17, 12, 2, 2, 'Product 2', 2, 450, 900),
(18, 13, 1, 2, 'Product 1', 3, 500, 1500),
(19, 13, 2, 2, 'Product 2', 2, 450, 900),
(20, 14, 1, 2, 'Product 1', 2, 500, 1000),
(21, 14, 2, 2, 'Product 2', 2, 450, 900),
(22, 15, 1, 2, 'Product 1', 3, 500, 1500),
(23, 15, 2, 2, 'Product 2', 3, 450, 1350),
(24, 16, 1, 2, 'Product 1', 2, 500, 1000),
(25, 16, 2, 2, 'Product 2', 3, 450, 1350),
(26, 17, 1, 2, 'Product 1', 5, 500, 2500),
(27, 17, 2, 2, 'Product 2', 3, 450, 1350),
(28, 18, 2, 2, 'Product 2', 1, 450, 450),
(29, 19, 2, 2, 'Product 2', 1, 450, 450),
(30, 19, 2, 2, 'Product 2', 2, 450, 900),
(31, 20, 2, 2, 'Product 2', 1, 450, 450),
(32, 21, 2, 2, 'Product 2', 1, 450, 450),
(33, 22, 1, 2, 'Product 1', 2, 500, 1000),
(34, 22, 2, 2, 'Product 2', 3, 450, 1350),
(35, 22, 4, 2, 'Product 3', 4, 700, 2800),
(36, 23, 2, 2, 'Product 2', 5, 450, 2250);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` int(11) NOT NULL,
  `cName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `cName`) VALUES
(1, 'Pakistani Sweets'),
(2, 'Arabian Sweets'),
(3, 'Turkish Sweets');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `totalAmount` int(11) NOT NULL,
  `status` enum('confirmed','pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  `amountRecieved` int(11) DEFAULT NULL,
  `paymentDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`oid`, `uid`, `name`, `address`, `phone`, `totalAmount`, `status`, `amountRecieved`, `paymentDate`) VALUES
(21, 2, 'Test user', 'pak', '+9230000000', 450, 'completed', 450, '2022-12-31'),
(22, 2, 'Arshad', 'Pakistan', '3333', 5150, 'pending', NULL, NULL),
(23, 2, 'Ahmed', 'Pak, Lahore', '54444', 2250, 'confirmed', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `pName` text NOT NULL,
  `pPrice` int(11) NOT NULL,
  `pQuantity` int(11) NOT NULL,
  `pImage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `cid`, `pName`, `pPrice`, `pQuantity`, `pImage`) VALUES
(1, 1, 'Gulab Jamun', 500, 50, 'gulab_jamun.jpg'),
(2, 2, 'Baklava', 450, 100, 'baklava.jpg'),
(3, 3, 'Turkish Delight', 700, 50, 'turkish_delight.jpg'),
(4, 1, 'Jalebi', 400, 60, 'jalebi.jpg'),
(5, 1, 'Ras Malai', 600, 40, 'ras_malai.jpg'),
(6, 1, 'Barfi', 350, 70, 'barfi.jpg'),
(7, 1, 'Ladoo', 300, 80, 'ladoo.jpg'),
(8, 1, 'Kheer', 550, 30, 'kheer.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `role` enum('customer','admin') NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'Admin', 'admin@gmail.com', 'admin1234', 'admin'),
(2, 'Test User 1', 't@gmail.com', 'a', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `products`
--
ALTER TABLE `