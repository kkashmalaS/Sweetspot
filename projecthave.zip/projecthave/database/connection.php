<?php
   $server = 'localhost';
   $user = 'root';
   $password= '';
   $db = 'onlinesweet';

   $conn = mysqli_connect($server, $user, $password, $db);

   if(!$conn)
   {
        echo mysqli_connect_error();
   }

   function navigate($message, $location='')
   {
      if(!empty($message))
      {
         echo '
         <script>
            alert("'.$message.'");
            window.location.replace("'.$location.'");
         </script> ';
      }
      echo '
         <script>
            window.location.replace("'.$location.'");
         </script> ';
   }
?>